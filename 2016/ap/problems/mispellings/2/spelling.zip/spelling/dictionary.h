/**
 * dictionary.h
 *
 * David J. Malan
 * malan@harvard.edu
 *
 * Declares a dictionary's functionality.
 */

#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdbool.h>

// maximum length for a word
// (e.g., pneumonoultramicroscopicsilicovolcanoconiosis)
#define LENGTH 45

// number of buckets in hash table
#define BUCKETS 26

// a node
typedef struct node
{
    char word[LENGTH + 1];
    struct node* next;
}
node;

// hash table
node* table[BUCKETS];

// number of words in dictionary
unsigned int words;

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word);

/**
 * Hashes word using its first character, returning value in [0,25].
 * Assumes word is alphabetical and of length >= 1.
 */
int hash(const char* word);


/**
 * Loads dictionary into memory. Returns true if successful else false.
 */
bool load(const char* dictionary);

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void);

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void);

#endif // DICTIONARY_H
